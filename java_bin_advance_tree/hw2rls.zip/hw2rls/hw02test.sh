java Hw02 in-10.txt > stu-10.txt
diff -w stu-10.txt base-10.txt
java Hw02 in-50.txt > stu-50.txt
diff -w stu-50.txt base-50.txt
java Hw02 in-100.txt > stu-100.txt
diff -w stu-100.txt base-100.txt
java Hw02 in-1000.txt > stu-1000.txt
diff -w stu-1000.txt base-1000.txt
java Hw02 in-5000.txt > stu-5000.txt
diff -w stu-5000.txt base-5000.txt
